# Oracle Questions: How Should We Improve Tetra Triton Attention?

We implemented custom flat Triton attention for Matterformer Tetra attention because we want to add geometric logit bias, specifically radial RBF bias, without materializing dense `[N, N, H]` tensors.

The current production no-bias backend is FlashAttention varlen with `q/k/v` cast to bf16. The custom Triton backend uses fp32 tensors and `input_precision="tf32x3"`.

## Architecture Context

Tetra attention flattens the finite tetra group frame axis and per-frame head axis:

```text
group_order = 12
heads_per_frame = 5
total_heads = 60
head_dim = 32
q/k/v shape after projections/RoPE: [tokens, 60, 32]
```

The current attention is framewise after flattening. There is no explicit key-frame axis `g'`; each flattened `(g,h)` head attends over tokens.

Current Flash path:

```python
flash_attn_varlen_func(
    q.contiguous().to(torch.bfloat16),
    k.contiguous().to(torch.bfloat16),
    v.contiguous().to(torch.bfloat16),
    cu_seqlens_q=cu_seqlens,
    cu_seqlens_k=cu_seqlens,
    max_seqlen_q=max_seqlen,
    max_seqlen_k=max_seqlen,
    dropout_p=0.0,
    causal=False,
).to(orig_dtype)
```

Current Triton radial RBF bias:

```text
score_ijh = q_i dot k_j / sqrt(d) + gate_factor[h] * sum_m w[h,m] * exp(-gamma * (||x_j - x_i|| - center_m)^2)
```

Radial params are shared over tetra group frames:

```text
subhead = head_idx % heads_per_frame
rbf_weight: [heads_per_frame, num_rbf]
gate:       [heads_per_frame]
```

Zero-init radial RBF is exactly a no-op relative to Triton no-bias.

## Current Performance

Synthetic ragged batch:

```text
segments=202
tokens=12000
heads=60
head_dim=32
max_seqlen=253
mean_len=59.4
median_len=50
sum_n2=1,005,542
GPU=NVIDIA RTX 6000 Ada Generation
```

Median timings:

```text
Flash bf16 no-bias current:
  forward: 0.919 ms
  fwd+bwd: 3.443 ms

Triton tf32x3 no-bias, auto split backward:
  forward: 0.733 ms
  fwd+bwd: 4.976 ms

Triton tf32x3 radial RBF8, auto atomic backward:
  forward: 1.283 ms
  fwd+bwd: 8.809 ms
```

So no-bias Triton forward is close or faster, but no-bias fwd+bwd is still 1.45x Flash time. Radial fwd+bwd is 2.56x Flash time.

## Implemented Optimization Attempts

1. Removed host/device sync from recomputing `max_seqlen`.
2. Early-return padded query blocks.
3. Skip invalid key-block bodies.
4. Fixed `P @ V` precision to honor `input_precision`.
5. Tried split backward:

```text
dQ kernel:
  query-block programs
  loops over key blocks
  writes dq once

dK/dV kernel:
  key-block programs
  loops over query blocks
  writes dk/dv once
```

Split backward helps no-bias but hurts radial because it recomputes the expensive RBF geometry and exponentials in both kernels.

Current default:

```text
MATTERFORMER_PLATONIC_TRITON_BWD=auto
  no-bias -> split
  radial  -> atomic
```

## Questions

1. What is the best next implementation change to make **no-bias Triton fwd+bwd roughly match FlashAttention fwd+bwd**?

Please rank these options:

```text
A. bf16-compatible Triton path matching Flash q/k/v dtype
B. better split backward layout / tile sizes
C. dK/dV kernel without atomics but with more Flash-like tiling
D. persistent or grouped-head kernels
E. ragged tile table instead of max-seqlen grid
F. different BLOCK_M/BLOCK_N/warps
G. use FlashAttention for no-bias and only custom kernel for radial
```

2. Is our split backward design fundamentally reasonable, or does it recompute too much compared with how FlashAttention backward is organized?

3. For no-bias Triton, should the next target be dtype parity with Flash:

```text
q/k/v bf16 inputs, output cast back to fp32
```

or should we keep fp32/tf32x3 and accept that it is not the same model numerically?

4. How should we verify no-bias accuracy when Flash uses bf16 and Triton uses tf32x3?

Current no-bias output difference vs Flash bf16:

```text
out_max_abs = 0.007264971733093262
out_rel_rms = 0.002634540433064103
```

Is this acceptable for backend smoke testing, or should we implement a Flash-compatible bf16 Triton mode first?

5. For radial RBF, what is the best speed strategy?

Please rank:

```text
A. Keep radial in atomic backward, optimize forward only
B. Precompute pair RBF basis per segment once and reuse across heads/layers
C. Replace Gaussian RBF with cheaper slope/r^2 polynomial bias
D. Add partial buffers for d_rbf_weight/d_gate instead of atomics
E. Split dK/dV but avoid recomputing RBF twice through saved tile summaries
F. Compute RBF once per group-shared subhead rather than per flattened head
G. Keep global attention as Flash and put radial geometry in a separate local KNN branch
```

6. Is it realistic to make radial global dense bias competitive with Flash no-bias, given:

```text
head_dim = 32
num_rbf = 8
60 flattened heads
RBF basis shared over only 5 subheads but currently recomputed per flattened head
```

7. Should we change the first geometric-bias experiment from RBF8 to a cheaper radial slope or squared-distance slope to make a deployable Triton path first?

8. What exact one-change-at-a-time verification plan would you recommend from here?

Please include:

```text
correctness tests
timing metrics
expected pass/fail thresholds
which benchmark distributions to use
when to revert an optimization
```

9. Are there specific Triton code patterns in `implementation/triton_attention_current.py` that are obviously suboptimal or risky?

10. Please propose the next 3 patches in order, with expected speed impact and correctness risk.
