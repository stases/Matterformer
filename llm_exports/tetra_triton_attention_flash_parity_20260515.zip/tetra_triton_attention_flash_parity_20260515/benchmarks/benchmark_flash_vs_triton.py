import json
import math
import os

import numpy as np
import torch
from flash_attn import flash_attn_varlen_func

from matterformer.models.platonic.triton_attention import platonic_attention_flat_triton


def make_lengths(num_segments=202, total=12000, max_len=253, seed=7):
    rng = np.random.default_rng(seed)
    lengths = np.clip(rng.gamma(2.0, 28.0, size=num_segments).astype(np.int64) + 1, 1, max_len)
    lengths[0] = max_len
    while int(lengths.sum()) < total:
        idx = int(rng.choice(np.flatnonzero(lengths < max_len)))
        lengths[idx] += min(max_len - int(lengths[idx]), total - int(lengths.sum()), int(rng.integers(1, 16)))
    while int(lengths.sum()) > total:
        idx = int(rng.choice(np.flatnonzero(lengths > 1)))
        lengths[idx] -= min(int(lengths[idx]) - 1, int(lengths.sum()) - total, int(rng.integers(1, 16)))
    return lengths.astype(np.int32)


def summarize(times):
    arr = np.array(times, dtype=np.float64)
    return {
        "mean_ms": float(arr.mean()),
        "median_ms": float(np.median(arr)),
        "std_ms": float(arr.std()),
        "p10_ms": float(np.percentile(arr, 10)),
        "p90_ms": float(np.percentile(arr, 90)),
    }


def rel_rms(a, b):
    return ((a - b).float().pow(2).mean().sqrt() / b.float().pow(2).mean().sqrt().clamp_min(1e-12)).item()


def max_abs(a, b):
    return (a - b).float().abs().max().item()


def main():
    torch.manual_seed(20260515)
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.set_float32_matmul_precision("high")

    device = "cuda"
    heads = 60
    head_dim = 32
    heads_per_frame = 5
    num_rbf = 8
    block_m = 16
    block_n = 32
    precision = "tf32x3"

    lengths = make_lengths()
    total_tokens = int(lengths.sum())
    max_seqlen = int(lengths.max())
    cu = torch.zeros(len(lengths) + 1, device=device, dtype=torch.int32)
    cu[1:] = torch.tensor(lengths, device=device, dtype=torch.int32).cumsum(0)

    generator = torch.Generator(device=device).manual_seed(1234)
    q0 = torch.randn((total_tokens, heads, head_dim), device=device, generator=generator) / math.sqrt(head_dim)
    k0 = torch.randn((total_tokens, heads, head_dim), device=device, generator=generator) / math.sqrt(head_dim)
    v0 = torch.randn((total_tokens, heads, head_dim), device=device, generator=generator)
    pos = torch.randn((total_tokens, 3), device=device, generator=generator) * 3.0
    dout = torch.randn((total_tokens, heads, head_dim), device=device, generator=generator)
    w0 = torch.randn((heads_per_frame, num_rbf), device=device, generator=generator) * 0.01
    gate0 = torch.randn((heads_per_frame,), device=device, generator=generator) * 0.01
    centers = torch.linspace(0.0, 6.0, num_rbf, device=device)
    gamma = torch.tensor(1.0 / float((6.0 / max(num_rbf - 1, 1)) ** 2), device=device)

    def flash_current(q, k, v):
        return flash_attn_varlen_func(
            q.contiguous().to(torch.bfloat16),
            k.contiguous().to(torch.bfloat16),
            v.contiguous().to(torch.bfloat16),
            cu_seqlens_q=cu,
            cu_seqlens_k=cu,
            max_seqlen_q=max_seqlen,
            max_seqlen_k=max_seqlen,
            dropout_p=0.0,
            causal=False,
        ).to(q.dtype)

    def triton_no_bias(q, k, v):
        os.environ["MATTERFORMER_PLATONIC_TRITON_BWD"] = "auto"
        return platonic_attention_flat_triton(
            q,
            k,
            v,
            cu_seqlens=cu,
            max_seqlen=max_seqlen,
            precision=precision,
            block_m=block_m,
            block_n=block_n,
            strict=True,
        )

    def triton_radial(q, k, v, w, gate):
        os.environ["MATTERFORMER_PLATONIC_TRITON_BWD"] = "auto"
        return platonic_attention_flat_triton(
            q,
            k,
            v,
            cu_seqlens=cu,
            max_seqlen=max_seqlen,
            pos=pos,
            heads_per_frame=heads_per_frame,
            rbf_weight=w,
            gate=gate,
            centers=centers,
            gamma=gamma,
            diag_zero=True,
            precision=precision,
            block_m=block_m,
            block_n=block_n,
            strict=True,
        )

    def bench_forward(name, fn, radial=False, warmup=8, repeat=40):
        with torch.no_grad():
            for _ in range(warmup):
                if radial:
                    fn(q0, k0, v0, w0, gate0)
                else:
                    fn(q0, k0, v0)
            torch.cuda.synchronize()
            times = []
            for _ in range(repeat):
                start = torch.cuda.Event(enable_timing=True)
                end = torch.cuda.Event(enable_timing=True)
                start.record()
                if radial:
                    fn(q0, k0, v0, w0, gate0)
                else:
                    fn(q0, k0, v0)
                end.record()
                end.synchronize()
                times.append(start.elapsed_time(end))
        return {"name": name, "pass": "fwd", **summarize(times)}

    def bench_fwd_bwd(name, fn, radial=False, warmup=8, repeat=40):
        q = q0.detach().clone().requires_grad_(True)
        k = k0.detach().clone().requires_grad_(True)
        v = v0.detach().clone().requires_grad_(True)
        if radial:
            w = w0.detach().clone().requires_grad_(True)
            gate = gate0.detach().clone().requires_grad_(True)
        else:
            w = gate = None

        def step():
            q.grad = None
            k.grad = None
            v.grad = None
            if radial:
                w.grad = None
                gate.grad = None
                out = fn(q, k, v, w, gate)
            else:
                out = fn(q, k, v)
            out.backward(dout)

        for _ in range(warmup):
            step()
        torch.cuda.synchronize()
        times = []
        for _ in range(repeat):
            start = torch.cuda.Event(enable_timing=True)
            end = torch.cuda.Event(enable_timing=True)
            start.record()
            step()
            end.record()
            end.synchronize()
            times.append(start.elapsed_time(end))
        return {"name": name, "pass": "fwd_bwd", **summarize(times)}

    rows = [
        bench_forward("flash_bf16_no_bias_current", flash_current),
        bench_fwd_bwd("flash_bf16_no_bias_current", flash_current),
        bench_forward("triton_tf32x3_no_bias_auto_split", triton_no_bias),
        bench_fwd_bwd("triton_tf32x3_no_bias_auto_split", triton_no_bias),
        bench_forward("triton_tf32x3_radial_rbf8_auto_atomic", triton_radial, radial=True),
        bench_fwd_bwd("triton_tf32x3_radial_rbf8_auto_atomic", triton_radial, radial=True),
    ]

    with torch.no_grad():
        out_flash = flash_current(q0, k0, v0)
        out_tri = triton_no_bias(q0, k0, v0)
        out_rad_zero = platonic_attention_flat_triton(
            q0,
            k0,
            v0,
            cu_seqlens=cu,
            max_seqlen=max_seqlen,
            pos=pos,
            heads_per_frame=heads_per_frame,
            rbf_weight=torch.zeros_like(w0),
            gate=torch.zeros_like(gate0),
            centers=centers,
            gamma=gamma,
            diag_zero=True,
            precision=precision,
            block_m=block_m,
            block_n=block_n,
            strict=True,
        )

    summary = {
        "gpu": torch.cuda.get_device_name(0),
        "torch": torch.__version__,
        "shape": {
            "segments": int(len(lengths)),
            "tokens": total_tokens,
            "heads": heads,
            "head_dim": head_dim,
            "max_seqlen": max_seqlen,
            "mean_len": float(lengths.mean()),
            "median_len": float(np.median(lengths)),
            "sum_n2": int((lengths.astype(np.int64) ** 2).sum()),
            "block_m": block_m,
            "block_n": block_n,
        },
        "precision": {"flash": "bf16 q/k/v cast inside current path", "triton": precision},
        "rows": rows,
        "parity": {
            "triton_no_bias_vs_flash_bf16": {
                "out_max_abs": max_abs(out_tri, out_flash),
                "out_rel_rms": rel_rms(out_tri, out_flash),
            },
            "radial_zero_vs_triton_no_bias": {
                "out_max_abs": max_abs(out_rad_zero, out_tri),
                "out_rel_rms": rel_rms(out_rad_zero, out_tri),
            },
        },
    }
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
