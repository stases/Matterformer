# Benchmark Results

## Environment

```text
GPU: NVIDIA RTX 6000 Ada Generation
torch: 2.5.0+cu124
flash_attn: 2.7.4.post1
Triton: 3.1.0
env python: /home/thadziv/GitHub/erwin/erwin/bin/python
partition/account: all6000 / all6000users
```

## Workload

Synthetic ragged OMol-like flat Tetra attention batch:

```text
segments:      202
tokens:        12000
heads:         60
head_dim:      32
max_seqlen:    253
mean_len:      59.4059
median_len:    50
sum_n2:        1005542
Triton blocks: BLOCK_M=16, BLOCK_N=32
```

Precision policy:

```text
Flash baseline:
  current production path casts q/k/v to bf16 inside flash_attn_varlen_func and casts output back to fp32.

Triton:
  q/k/v are fp32 tensors with input_precision="tf32x3".
```

## Timing Table

All timings are CUDA event timings, 8 warmup iterations and 40 measured iterations.

| Backend | Pass | Median ms | Mean ms | p10 ms | p90 ms |
|---|---:|---:|---:|---:|---:|
| Flash bf16 no-bias current | fwd | 0.919 | 0.920 | 0.915 | 0.924 |
| Flash bf16 no-bias current | fwd+bwd | 3.443 | 3.443 | 3.433 | 3.454 |
| Triton tf32x3 no-bias auto split | fwd | 0.733 | 0.760 | 0.724 | 0.950 |
| Triton tf32x3 no-bias auto split | fwd+bwd | 4.976 | 5.018 | 4.901 | 5.179 |
| Triton tf32x3 no-bias forced atomic | fwd | 0.883 | 0.894 | 0.876 | 0.907 |
| Triton tf32x3 no-bias forced atomic | fwd+bwd | 5.361 | 5.418 | 5.304 | 5.619 |
| Triton tf32x3 radial RBF8 auto atomic | fwd | 1.283 | 1.249 | 1.125 | 1.288 |
| Triton tf32x3 radial RBF8 auto atomic | fwd+bwd | 8.809 | 8.846 | 8.650 | 9.064 |

## Ratios vs Flash Current

Using medians:

```text
No-bias Triton fwd:
  0.733 / 0.919 = 0.80x Flash time

No-bias Triton fwd+bwd:
  4.976 / 3.443 = 1.45x Flash time

Radial RBF Triton fwd:
  1.283 / 0.919 = 1.40x Flash time

Radial RBF Triton fwd+bwd:
  8.809 / 3.443 = 2.56x Flash time
```

## Correctness / Parity Notes

Forward parity from the same benchmark:

```text
triton_no_bias_vs_flash_bf16:
  out_max_abs = 0.007264971733093262
  out_rel_rms = 0.002634540433064103

radial_zero_vs_triton_no_bias:
  out_max_abs = 0.0
  out_rel_rms = 0.0
```

Interpretation:

1. Triton radial zero-init is exactly a no-op relative to Triton no-bias.
2. Triton no-bias does not exactly match Flash because current Flash uses bf16 q/k/v while Triton uses fp32/tf32x3.
3. The important speed gap is backward, not forward. No-bias Triton forward is already in the same range as Flash, but fwd+bwd is slower.

## Earlier Stepwise Timing Context

Before the current split-backward experiment, after query/key schedule skipping:

```text
Flash fwd/bwd:                 0.921 / 3.570 ms
Triton no-bias atomic fwd/bwd: 0.747 / 4.980 ms
Triton radial atomic fwd/bwd:  1.080 / 8.628 ms
```

Split backward experiment:

```text
Small parity split vs atomic:
  no-bias dq exact, dk rel_rms ~5e-8, dv rel_rms ~4.6e-7
  radial dw rel_rms ~5.3e-7

Median fwd+bwd on one ragged batch:
  no-bias atomic: 5.268 ms
  no-bias split:  4.824 ms
  radial atomic:  8.404 ms
  radial split:   8.711 ms
```

Decision:

```text
auto no-bias -> split
auto radial  -> atomic
```
