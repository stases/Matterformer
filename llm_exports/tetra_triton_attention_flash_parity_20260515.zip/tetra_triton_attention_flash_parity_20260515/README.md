# Tetra Triton Attention / Flash Parity Oracle Context

This package describes the current Matterformer Tetra flat-attention implementation and the latest benchmark results.

Repo:

```text
/home/thadziv/GitHub/Matterformer
branch: modular-matterformer
base commit for this export: 68c45ea
```

Important worktree note from export time:

```text
src/matterformer/models/platonic/triton_attention.py contains the latest split-backward experiment.
Other dirty files in the repo are unrelated Fourier/linear work and are listed in git_status_short.txt.
```

## What Changed So Far

The Tetra flat attention path now has three main backends:

```text
attention_backend = "flash"              # current production baseline, no geometric bias
attention_backend = "triton"             # custom flat varlen Triton attention, no bias
attention_backend = "triton_radial_rbf"  # same Triton attention plus radial RBF logit bias
```

The important implementation work already done:

1. Added flat Triton attention for `q/k/v [tokens, heads, head_dim]` using `cu_seqlens` and `max_seqlen`.
2. Added radial RBF score bias shared over tetra group frames:

```text
rbf_weight: [heads_per_frame, num_rbf]
gate:       [heads_per_frame]
centers:    [num_rbf] buffer
gamma:      scalar buffer
```

3. Fixed forward value accumulation precision:

```python
tl.dot(p, v, input_precision=input_precision)
```

4. Avoided recomputing `max_seqlen` with a GPU `.item()` sync inside autograd.
5. Skipped padded query blocks and skipped invalid key-block bodies.
6. Added experimental split backward:

```text
MATTERFORMER_PLATONIC_TRITON_BWD=auto   # default
MATTERFORMER_PLATONIC_TRITON_BWD=atomic # old query-block backward with dk/dv atomics
MATTERFORMER_PLATONIC_TRITON_BWD=split  # split dQ and dK/dV kernels
```

Default auto behavior after benchmarking:

```text
no-bias Triton: split backward
radial RBF:     atomic backward
```

Reason: split backward helps no-bias but recomputes expensive RBF geometry in both kernels, so it is not consistently faster for radial RBF.

## Files Included

```text
implementation/triton_attention_current.py
  Current full Triton attention implementation including uncommitted split-backward experiment.

implementation/triton_attention_uncommitted_split_bwd.diff
  Diff from commit 68c45ea showing the split-backward changes at export time.

implementation/layers_HEAD.py
  Clean HEAD copy of PlatonicAttention integration layer.

configs/tetra_t_only_h1920_l16_pt2_exact_sin_layerscale_triton.json
  No-bias Triton config.

configs/tetra_t_only_h1920_l16_pt2_exact_sin_layerscale_radialrbf.json
  Radial RBF config.

tests/test_hybrid_current.py
  Current test file containing Platonic Triton and radial RBF tests.

benchmarks/flash_vs_triton_results.json
benchmarks/BENCHMARK_RESULTS.md
benchmarks/benchmark_flash_vs_triton.py
  Latest benchmark results and a self-contained reproducer.

ORACLE_QUESTIONS.md
  The main questions for another LLM/oracle.
```

## Current Bottom Line

On the synthetic ragged OMol-like workload:

```text
segments=202
tokens=12000
heads=60
head_dim=32
max_seqlen=253
mean_len=59.4
median_len=50
sum_n2=1,005,542
GPU=NVIDIA RTX 6000 Ada Generation
```

Flash no-bias is still faster for training:

```text
Flash bf16 no-bias fwd+bwd:       3.443 ms median
Triton tf32x3 no-bias fwd+bwd:    4.976 ms median
Triton tf32x3 radial RBF fwd+bwd: 8.809 ms median
```

Triton no-bias forward alone is close:

```text
Flash bf16 no-bias forward:       0.919 ms median
Triton tf32x3 no-bias forward:    0.733 ms median
Triton tf32x3 radial RBF forward: 1.283 ms median
```

But fwd+bwd is what matters for training, and the custom Triton backward is still not Flash-like enough.
